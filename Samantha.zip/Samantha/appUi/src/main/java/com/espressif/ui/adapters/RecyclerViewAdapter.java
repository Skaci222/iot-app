package com.espressif.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.espressif.ui.activities.DeviceItems;
import com.espressif.wifi_provisioning.R;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    private ArrayList<DeviceItems> mDeviceItems;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView tvCardTitle, tvCardStatus;

        public MyViewHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);

            tvCardTitle = itemView.findViewById(R.id.tvCardview);
            tvCardStatus = itemView.findViewById(R.id.tvCardStatus);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
    public RecyclerViewAdapter(ArrayList<DeviceItems> mDeviceItems){
        this.mDeviceItems = mDeviceItems;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.items, parent, false);
        return new MyViewHolder(v, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        DeviceItems currentItem = mDeviceItems.get(position);
        String deviceName = currentItem.getDeviceName();
        String deviceStatus = currentItem.getDeviceStatus();

        holder.tvCardTitle.setText(deviceName);
        holder.tvCardStatus.setText(deviceStatus);

    }

    @Override
    public int getItemCount() {
        return mDeviceItems.size();
    }

}
