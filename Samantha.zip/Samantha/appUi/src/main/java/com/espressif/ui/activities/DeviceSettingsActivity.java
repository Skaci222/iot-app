package com.espressif.ui.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.espressif.wifi_provisioning.R;

public class DeviceSettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_settings);
    }
}