package com.espressif.ui.activities;

public class DeviceItems {

    private String mDeviceName;
    private String mDeviceStatus;

    public DeviceItems(String deviceName, String deviceStatus){
        mDeviceName = deviceName;
        mDeviceStatus = deviceStatus;
    }

    public String getDeviceName() {
        return mDeviceName;
    }

    public String getDeviceStatus() {
        return mDeviceStatus;
    }
}
