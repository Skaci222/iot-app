package com.espressif.ui.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.espressif.ui.adapters.RecyclerViewAdapter;
import com.espressif.wifi_provisioning.R;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerViewAdapter mRecyclerViewAdapter;
    private ArrayList<DeviceItems> mDeviceItems;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);

        mRecyclerView = findViewById(R.id.recycler_view);
        layoutManager = new LinearLayoutManager(this);
        mDeviceItems = new ArrayList<>();
        mDeviceItems.add(new DeviceItems("Sample device 1", "Offline"));
        mDeviceItems.add(new DeviceItems("Sample device 2", "Offline"));
        mRecyclerViewAdapter = new RecyclerViewAdapter(mDeviceItems);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mRecyclerViewAdapter);

    }

}